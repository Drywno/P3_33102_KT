#include <cstdio>
#include <thread>
#include <windows.h>

void action() {
    printf("Uruchamiam watek %d\n", std::this_thread::get_id());
    Sleep(10 * 1000); 
    printf("Koncze watek %d\n", std::this_thread::get_id());
}

int main() {
    std::thread t1(action);
    std::thread t2(action);
    std::thread t3(action);

    t1.join();
    t2.join();
    t3.join();

    printf("Koniec programu \r\n");

    return 0;
}
