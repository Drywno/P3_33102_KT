#include <thread>
#include <cstdio>
#include <windows.h>
#include <cstdlib>
#include <ctime>

const int ARR_SIZE = 100;
int arr[ARR_SIZE];

unsigned int total_sum = 0;

thread_local unsigned int thread_sum = 0;

void sum_range(int id) {
    int start = id * 10;
    int end = (id + 1) * 10;

    for (int i = start; i < end; i++) {
        total_sum += arr[i];
    }
    for (int i = start; i < end; i++) {
        thread_sum += arr[i];
    }

    printf("Thread %d -> total_sum: %u, thread_sum: %u\n", id, total_sum, thread_sum);
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    for (int i = 0; i < ARR_SIZE; i++) {
        arr[i] = rand() % 10 + 1;
    }
    printf("Tablica:\n");
    for (int i = 0; i < ARR_SIZE; i++) {
        printf("%d ", arr[i]);
        if ((i + 1) % 10 == 0) {
            printf("\n");
        }
    }

    std::thread threads[10];
    for (int i = 0; i < 10; i++) {
        threads[i] = std::thread(sum_range, i);
    }

    for (int i = 0; i < 10; i++) {
        threads[i].join();
    }

    system("pause");

    return 0;
}
