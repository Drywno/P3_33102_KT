#include "mpi.h"
#include <cstdio>
#include <iostream>
#include <ctime>

void mainProcess(int size) {
    int N;
    std::cout << "Podaj rozmiar wektorow (podzielny przez " << size - 1 << "): ";
    std::cin >> N;

    if (N % (size - 1) != 0) {
        std::cerr << "Rozmiar musi byc podzielny przez liczbe procesow roboczych!\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int chunkSize = N / (size - 1);

    unsigned int* va = new unsigned int[N];
    unsigned int* vb = new unsigned int[N];
    unsigned int* vc = new unsigned int[N];

    srand(static_cast<unsigned int>(time(NULL)));
    for (int i = 0; i < N; i++) {
        va[i] = rand() % 10;
        vb[i] = rand() % 10;
        vc[i] = 0;
    }

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(va, N, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(vb, N, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    MPI_Request* requests = new MPI_Request[size - 1];
    MPI_Status* statuses = new MPI_Status[size - 1];
    for (int i = 1; i < size; i++) {
        MPI_Irecv(vc + (i - 1) * chunkSize, chunkSize, MPI_UNSIGNED, i, 0, MPI_COMM_WORLD, &requests[i - 1]);
    }

    MPI_Waitall(size - 1, requests, statuses);

    std::cout << "Wektor A:\n";
    for (int i = 0; i < N; i++) std::cout << va[i] << "\t";
    std::cout << "\nWektor B:\n";
    for (int i = 0; i < N; i++) std::cout << vb[i] << "\t";
    std::cout << "\nSuma (A + B):\n";
    for (int i = 0; i < N; i++) std::cout << vc[i] << "\t";
    std::cout << std::endl;

    delete[] va;
    delete[] vb;
    delete[] vc;
    delete[] requests;
    delete[] statuses;
}

void workerProcess(int id, int size) {
    int N;
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int chunkSize = N / (size - 1);

    unsigned int* va = new unsigned int[N];
    unsigned int* vb = new unsigned int[N];
    unsigned int* vc = new unsigned int[chunkSize];

    MPI_Bcast(va, N, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(vb, N, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    int start = (id - 1) * chunkSize;
    for (int i = 0; i < chunkSize; i++) {
        vc[i] = va[start + i] + vb[start + i];
    }

    MPI_Send(vc, chunkSize, MPI_UNSIGNED, 0, 0, MPI_COMM_WORLD);

    delete[] va;
    delete[] vb;
    delete[] vc;
}

int main() {
    int PID, PCOUNT;

    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &PID);
    MPI_Comm_size(MPI_COMM_WORLD, &PCOUNT);

    if (PCOUNT < 2) {
        std::cerr << "Potrzeba co najmniej 2 procesów.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    if (PID == 0)
        mainProcess(PCOUNT);
    else
        workerProcess(PID, PCOUNT);

    MPI_Finalize();

    return 0;
}
