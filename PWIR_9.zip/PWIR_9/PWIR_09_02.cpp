﻿#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <chrono>
#include <cassert>
#include <ctime>
#include <cmath>
#include <omp.h>

#define VECTOR_SIZE 10000

float* vector;

void createAndFillVector() {
    vector = new float[VECTOR_SIZE];
    srand((unsigned int)time(NULL));

    for (uint32_t i = 0; i < VECTOR_SIZE; i++) {
        vector[i] = static_cast<float>(rand() % 11);
    }
}

float calculateVectorLengthSequential() {
    float sum = 0.0f;
    for (uint32_t i = 0; i < VECTOR_SIZE; i++) {
        sum += vector[i] * vector[i];
    }
    return sqrtf(sum);
}

float calculateVectorLengthParallel() {
    float sum = 0.0f;

#pragma omp parallel for reduction(+ : sum)
    for (int32_t i = 0; i < VECTOR_SIZE; i++) {
        sum += vector[i] * vector[i];
    }
    return sqrtf(sum);
}

void freeVector() {
    delete[] vector;
}

int main() {
    createAndFillVector();

    auto start = std::chrono::high_resolution_clock::now();
    float lenSeq = calculateVectorLengthSequential();
    auto end = std::chrono::high_resolution_clock::now();
    printf("Vector length (sekwencyjnie): %.6f in time: %llu ms\r\n",
        lenSeq, std::chrono::duration_cast<std::chrono::microseconds>(end - start).count());

    start = std::chrono::high_resolution_clock::now();
    float lenPar = calculateVectorLengthParallel();
    end = std::chrono::high_resolution_clock::now();
    printf("Vector length (rownolegle):   %.6f in time: %llu ms\r\n",
        lenPar, std::chrono::duration_cast<std::chrono::microseconds>(end - start).count());

    freeVector();

    return 0;
}
