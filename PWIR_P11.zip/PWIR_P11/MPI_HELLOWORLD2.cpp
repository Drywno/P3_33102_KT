#include "mpi.h"
#include <cstdio>
#include <iostream>
#include <ctime>

const int CHUNK_SIZE = 10;  // zmienione z 5

void mainProcess(int size) {
    unsigned int* va = new unsigned int[CHUNK_SIZE * (size - 1)];
    unsigned int* vb = new unsigned int[CHUNK_SIZE * (size - 1)];
    unsigned int* vc = new unsigned int[CHUNK_SIZE * (size - 1)];

    srand(static_cast<unsigned int>(time(NULL)));
    for (unsigned int i = 0; i < CHUNK_SIZE * (size - 1); i++) {
        va[i] = rand() % 10;
        vb[i] = rand() % 10;
        vc[i] = 0;
    }

    MPI_Bcast(va, CHUNK_SIZE * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(vb, CHUNK_SIZE * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    MPI_Request* requests = new MPI_Request[size - 1];
    MPI_Status* statuses = new MPI_Status[size - 1];
    for (unsigned int i = 0; i < size - 1; i++) {
        MPI_Irecv(vc + i * CHUNK_SIZE, CHUNK_SIZE, MPI_UNSIGNED, i + 1, 0, MPI_COMM_WORLD, &requests[i]);
    }
    MPI_Waitall(size - 1, requests, statuses);

    for (unsigned int i = 0; i < CHUNK_SIZE * (size - 1); i++) printf("%d\t", va[i]);
    printf("\n");
    for (unsigned int i = 0; i < CHUNK_SIZE * (size - 1); i++) printf("%d\t", vb[i]);
    printf("\n");
    for (unsigned int i = 0; i < CHUNK_SIZE * (size - 1); i++) printf("%d\t", vc[i]);
    printf("\n");

    delete[] va;
    delete[] vb;
    delete[] vc;
    delete[] requests;
    delete[] statuses;
}

void workerProcess(int id, int size) {
    unsigned int* v = new unsigned int[CHUNK_SIZE];
    unsigned int* va = new unsigned int[CHUNK_SIZE * (size - 1)];
    unsigned int* vb = new unsigned int[CHUNK_SIZE * (size - 1)];

    MPI_Bcast(va, CHUNK_SIZE * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(vb, CHUNK_SIZE * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    for (unsigned int i = 0; i < CHUNK_SIZE; i++) {
        v[i] = va[(id - 1) * CHUNK_SIZE + i] + vb[(id - 1) * CHUNK_SIZE + i];
    }

    MPI_Send(v, CHUNK_SIZE, MPI_UNSIGNED, 0, 0, MPI_COMM_WORLD);

    delete[] v;
    delete[] va;
    delete[] vb;
}

int main() {
    int PID, PCOUNT;

    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &PID);
    MPI_Comm_size(MPI_COMM_WORLD, &PCOUNT);

    if (PID == 0)
        mainProcess(PCOUNT);
    else
        workerProcess(PID, PCOUNT);

    MPI_Finalize();

    return 0;

    system('pause');
}
