#include <chrono>
#include <cstdio>
#include <windows.h>
#include <vector>

std::vector<unsigned long long> generujFibonacci(int n) {
    std::vector<unsigned long long> fib(n);
    fib[0] = 0;
    if (n > 1) {
        fib[1] = 1;
        for (int i = 2; i < n; ++i) {
            fib[i] = fib[i - 1] + fib[i - 2];
        }
    }
    return fib;
}

int main() {
    auto start = std::chrono::steady_clock::now();
    //długie operacje
    Sleep(2000);
    auto end = std::chrono::steady_clock::now();

    printf("Czas trwania: %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());

    int n = 10000000;
    std::vector<unsigned long long> fibonacci = generujFibonacci(n);

    printf("Ciag Fibonacciego: ");
    for (int i = 0; i < n; ++i) {
        printf("%llu ", fibonacci[i]);
    }
    printf("\n");


    system("pause");
    return 0;
}