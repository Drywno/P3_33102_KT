﻿#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <chrono>
#include <cassert>
#include <ctime>
#include <omp.h>

#define MATRIX_H 3000
#define MATRIX_W 3000
#define VECTOR_S 3000
#define MUL_TIME 5

uint16_t** matrix;
uint16_t* vector;
uint32_t* result; // <- rozszerzone do uint32_t, bo przy MUL_TIME i dużych macierzach łatwo o przepełnienie

void initialize_matrix_vector() {
    srand((unsigned int)time(NULL));

    // Matrix allocation
    matrix = new uint16_t * [MATRIX_H];
    for (int32_t i = 0; i < MATRIX_H; i++) {
        matrix[i] = new uint16_t[MATRIX_W];
    }

    // Vector and result allocation
    vector = new uint16_t[VECTOR_S];
    result = new uint32_t[MATRIX_H];

    // Fill matrix and vector with random data
#pragma omp parallel for collapse(2)
    for (int32_t i = 0; i < MATRIX_H; i++) {
        for (int32_t k = 0; k < MATRIX_W; k++) {
            matrix[i][k] = (uint16_t)(rand() % 100);
        }
    }

#pragma omp parallel for
    for (int32_t i = 0; i < VECTOR_S; i++) {
        vector[i] = (uint16_t)(rand() % 100);
    }
}

void free_memory() {
    for (int32_t i = 0; i < MATRIX_H; i++) {
        delete[] matrix[i];
    }
    delete[] matrix;
    delete[] vector;
    delete[] result;
}

void clear_result() {
#pragma omp parallel for
    for (int32_t i = 0; i < MATRIX_H; i++) {
        result[i] = 0;
    }
}

void multiply_matrix_vector_static() {
    auto start = std::chrono::high_resolution_clock::now();
    for (uint32_t p = 0; p < MUL_TIME; p++) {
        clear_result();
#pragma omp parallel for schedule(static)
        for (int32_t i = 0; i < MATRIX_H; i++) {
            uint32_t sum = 0;
            for (int32_t k = 0; k < MATRIX_W; k++) {
                sum += matrix[i][k] * vector[k];
            }
            result[i] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    printf("Static scheduling: %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
}

void multiply_matrix_vector_static_chunk() {
    auto start = std::chrono::high_resolution_clock::now();
    for (uint32_t p = 0; p < MUL_TIME; p++) {
        clear_result();
#pragma omp parallel for schedule(static, MATRIX_H / 10)
        for (int32_t i = 0; i < MATRIX_H; i++) {
            uint32_t sum = 0;
            for (int32_t k = 0; k < MATRIX_W; k++) {
                sum += matrix[i][k] * vector[k];
            }
            result[i] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    printf("Static scheduling with chunk (MATRIX_H/10): %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
}

void multiply_matrix_vector_dynamic() {
    auto start = std::chrono::high_resolution_clock::now();
    for (uint32_t p = 0; p < MUL_TIME; p++) {
        clear_result();
#pragma omp parallel for schedule(dynamic, MATRIX_H / 10)
        for (int32_t i = 0; i < MATRIX_H; i++) {
            uint32_t sum = 0;
            for (int32_t k = 0; k < MATRIX_W; k++) {
                sum += matrix[i][k] * vector[k];
            }
            result[i] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    printf("Dynamic scheduling: %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
}

void multiply_matrix_vector_guided() {
    auto start = std::chrono::high_resolution_clock::now();
    for (uint32_t p = 0; p < MUL_TIME; p++) {
        clear_result();
#pragma omp parallel for schedule(guided, MATRIX_H / 10)
        for (int32_t i = 0; i < MATRIX_H; i++) {
            uint32_t sum = 0;
            for (int32_t k = 0; k < MATRIX_W; k++) {
                sum += matrix[i][k] * vector[k];
            }
            result[i] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    printf("Guided scheduling: %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
}

void multiply_matrix_vector_runtime() {
    auto start = std::chrono::high_resolution_clock::now();
    for (uint32_t p = 0; p < MUL_TIME; p++) {
        clear_result();
#pragma omp parallel for schedule(runtime)
        for (int32_t i = 0; i < MATRIX_H; i++) {
            uint32_t sum = 0;
            for (int32_t k = 0; k < MATRIX_W; k++) {
                sum += matrix[i][k] * vector[k];
            }
            result[i] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    printf("Runtime scheduling: %llu ms\n", std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
}

int main() {
    assert(MATRIX_W == VECTOR_S);

    initialize_matrix_vector();

    multiply_matrix_vector_static();
    multiply_matrix_vector_static_chunk();
    multiply_matrix_vector_dynamic();
    multiply_matrix_vector_guided();
    multiply_matrix_vector_runtime();

    free_memory();

    return 0;
}
