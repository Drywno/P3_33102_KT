#include <iostream>
#include <vector>
#include <random>
#include <cmath>
#include <chrono>
#include <omp.h>

constexpr int VECTOR_SIZE = 1000;
constexpr int THREADS     = 4;

int main() {
    std::vector<double> data(VECTOR_SIZE);


    #pragma omp parallel num_threads(THREADS)
    {
        std::mt19937_64 rng(std::random_device{}() ^ (std::uint64_t)omp_get_thread_num());
        std::uniform_real_distribution<double> dist(0.0, 1.0);

        #pragma omp for schedule(static)
        for (int i = 0; i < VECTOR_SIZE; ++i) {
            data[i] = dist(rng);
        }
    }


    auto t0 = std::chrono::high_resolution_clock::now();

    double sum_sq = 0.0;
    #pragma omp parallel for num_threads(THREADS) reduction(+:sum_sq) schedule(static)
    for (int i = 0; i < VECTOR_SIZE; ++i) {
        sum_sq += data[i] * data[i];
    }

    double norm = std::sqrt(sum_sq);

    auto t1 = std::chrono::high_resolution_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();

    std::cout  
        << "wektor: " << norm  << "\n"
        << "czas: "        << ms    << " ms\n";

    return 0;
}
