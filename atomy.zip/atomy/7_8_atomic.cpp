#include <thread>
#include <cstdio>
#include <windows.h>
#include <atomic>
#include <chrono>

std::atomic<unsigned int> counter(0);
bool stop_program = false;
const unsigned int MAX_ITERATIONS = 100;

void increment() {
    for (unsigned int i = 0; i < MAX_ITERATIONS; i++) {
        counter++; // operacja atomowa
        Sleep(200);
    }
}

void parity() {
    for (unsigned int i = 0; i < MAX_ITERATIONS; i++) {
        unsigned int current = counter.load(); // odczyt atomowy
        if (current % 2) {
            printf("%u jest nieparzyste\r\n", current);
        }
        else {
            printf("%u jest parzyste\r\n", current);
        }
        Sleep(200);
    }
    stop_program = true;
}

int main() {
    auto start = std::chrono::high_resolution_clock::now();

    std::thread inc(increment);
    std::thread par(parity);

    inc.join();
    par.join();

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;

    printf("Done\r\n");
    printf("Czas wykonania: %.2f sekundy\r\n", duration.count());

    return 0;
}
