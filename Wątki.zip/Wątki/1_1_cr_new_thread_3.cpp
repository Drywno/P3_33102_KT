#include <cstdio>
#include <thread>
#include <windows.h>

void action(int id, int sleep_time) {
    printf("Uruchamiam watek %d\n", id);
    Sleep(sleep_time * 1000); 
    printf("Koncze watek %d\n", id);
}

int main() {
    std::thread t1(action, 1, 5); 
    std::thread t2(action, 2, 8);  
    std::thread t3(action, 3, 3);  

    t1.join();
    t2.join();
    t3.join();

    printf("Koniec programu \r\n");

    return 0;
}