#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

int main() {
    const int total_points = 1000000;
    int points_in_circle = 0;

    srand(time(NULL)); // Ustawienie pocz�tkowego seed-a

#pragma omp parallel
    {
        int local_count = 0;

#pragma omp for
        for (int i = 0; i < total_points; i++) {
            double x, y;

            // Wygenerowanie liczb losowych w sekcji krytycznej
#pragma omp critical
            {
                x = (double)rand() / RAND_MAX;
                y = (double)rand() / RAND_MAX;
            }

            if (x * x + y * y <= 1.0) {
                local_count++;
            }
        }

#pragma omp atomic
        points_in_circle += local_count;
    }

    double pi = 4.0 * points_in_circle / total_points;
    printf("Przyblizona wartosc PI: %f\n", pi);

    system("pause");

    return 0;
}
