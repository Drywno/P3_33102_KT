#include "mpi.h"
#include <cstdio>
#include <iostream>
#include <time.h>

void mainProcess(int size) {
	srand(time(NULL));

	//alokujemy wektory o rozmiarze(5*(ilosc procesw-1))
	unsigned int* va = new unsigned int[5 * (size - 1)];
	unsigned int* vb = new unsigned int[5 * (size - 1)];
	unsigned int* vc = new unsigned int[5 * (size - 1)];

	//wypeniamy a i b losowymi danymi, a vc zerujemy
	for (unsigned int i = 0; i < 5 * (size - 1); i++) {
		va[i] = rand() % 10;
		vb[i] = rand() % 10;
		vc[i] = 0;
	}

	//broadcastujemy wektor a do pozostaych procesw
	MPI_Bcast(va, 5 * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

	//broadcastujemy wektor b do pozostaych procesw
	MPI_Bcast(vb, 5 * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

	//odpalamy nas�uch
	MPI_Request* requests = new MPI_Request[size - 1];
	MPI_Status* statuses = new MPI_Status[size - 1];
	for (unsigned int i = 0; i < size-1; i++) {
		MPI_Irecv(vc + i * 5, 5, MPI_UNSIGNED, i + 1, 0, MPI_COMM_WORLD, &requests[i]);
	}
	MPI_Waitall(size - 1, requests, statuses);

	//wypisujemy wyniki
	for (unsigned int i = 0; i < (5 * (size - 1)); i++) printf("%d\t", va[i]);
	printf("\r\n");
	for (unsigned int i = 0; i < (5 * (size - 1)); i++) printf("%d\t", vb[i]);
	printf("\r\n");
	for (unsigned int i = 0; i < (5 * (size - 1)); i++) printf("%d\t", vc[i]);
	printf("\r\n");

	//zwalniamy pami
	delete[] va;
	delete[] vb;
	delete[] vc;
	delete[] requests;
	delete[] statuses;
}

void workerProcess(int id, int size) {
	//alokujemy buffor na moj cz zadania
	unsigned int* v = new unsigned int[5];

	//alokujemny miejsce na wektor a oraz b
	unsigned int* va = new unsigned int[5 * (size - 1)];
	unsigned int* vb = new unsigned int[5 * (size - 1)];

	//nasuchujemy bcasta wektora a
	MPI_Bcast(va, 5 * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

	//nasuchujemy bcasta wektora b
	MPI_Bcast(vb, 5 * (size - 1), MPI_UNSIGNED, 0, MPI_COMM_WORLD);

	//liczymy sum
	for (unsigned int i = 0; i < 5; i++) {
		v[i] = va[(id - 1) * 5 + i] + vb[(id - 1) * 5 + i];
	}

	//odsyamy wynik
	MPI_Send(v, 5, MPI_UNSIGNED, 0, 0, MPI_COMM_WORLD);

	//zwalniamy pamic
	delete[] v;
	delete[] va;
	delete[] vb;
}

int main()
{
	int PID, PCOUNT;

	MPI_Init(NULL, NULL);

	MPI_Comm_rank(MPI_COMM_WORLD, &PID);
	MPI_Comm_size(MPI_COMM_WORLD, &PCOUNT);

	if (PID == 0) { //jestem procesem gwnym
		mainProcess(PCOUNT);
	}
	else { //jestem procesem roboczym
		workerProcess(PID, PCOUNT);
	}
	
	MPI_Finalize();
	
	return 0;
}

