#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <vector>
#include <chrono>

#define SIZE 40
#define THREAD_COUNT 4
#define CHUNK_SIZE (SIZE / THREAD_COUNT)

void add(int id, int* a, int* b, int* c) {
    int start = id * CHUNK_SIZE;
    int end = start + CHUNK_SIZE;
    for (int i = start; i < end; i++) {
        c[i] = a[i] + b[i];
    }
}

int main() {
    srand(time(NULL));
    int a[SIZE], b[SIZE], c[SIZE];

    for (int i = 0; i < SIZE; i++) {
        a[i] = rand() % 100 + 1;
        b[i] = rand() % 100 + 1;
    }

    // Wypisanie na ekranie A
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    // Wypisanie na ekranie B
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", b[i]);
    }
    printf("\n");

    std::vector<std::thread> threads;
    auto start_time = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < THREAD_COUNT; i++) {
        threads.emplace_back(add, i, a, b, c);
    }

    for (auto& th : threads) {
        th.join();
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end_time - start_time;

    printf("Czas obliczeń: %f sekund\n", elapsed.count());

    // Wypisanie na ekranie C
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", c[i]);
    }
    printf("\n");


    system("pause");

    return 0;
}
