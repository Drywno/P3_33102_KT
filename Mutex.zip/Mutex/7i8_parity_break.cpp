#include <thread>
#include <cstdio>
#include <windows.h>
#include <mutex>
#include <chrono>

std::mutex counter_mutex;
unsigned int counter = 0;
const unsigned int MAX_ITERATIONS = 5; 

void increment() {
    for (unsigned int i = 0; i < MAX_ITERATIONS; i++) {
        counter_mutex.lock();
        counter++;
        counter_mutex.unlock();
        Sleep(2000);
    }
}

void parity() {
    for (unsigned int i = 0; i < MAX_ITERATIONS; i++) {
        counter_mutex.lock();
        if (counter % 2) {
            printf("%u jest nieparzyste\r\n", counter);
        }
        else {
            printf("%u jest parzyste\r\n", counter);
        }
        counter_mutex.unlock();
        Sleep(2000);

        if (i == MAX_ITERATIONS - 1) {
            break;
        }
    }
}

int main() {
    auto start = std::chrono::high_resolution_clock::now();

    std::thread inc(increment);
    std::thread par(parity);

    inc.join();
    par.join();

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;

    printf("Done\r\n");
    printf("Czas wykonania: %.2f sekundy\r\n", duration.count());

    system("pause");

    return 0;
}
