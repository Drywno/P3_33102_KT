#include <cstdio>
#include <thread>
#include <windows.h>
#include <iostream>

void action(int id) {
    printf("Uruchamiam watek %d\n", id);
    Sleep(5 * 1000); // 5 sekund
    printf("Koncze watek %d\n", id);
}

int main() {
    int thread_count;

   
    printf("Podaj liczbe watkow: ");
    std::cin >> thread_count;

   
    std::thread** threads = new std::thread * [thread_count];

 
    for (int i = 0; i < thread_count; i++) {
        threads[i] = new std::thread(action, i);
    }

 
    for (int i = 0; i < thread_count; i++) {
        threads[i]->join();
    }

    for (int i = 0; i < thread_count; i++) {
        delete threads[i];
    }
    delete[] threads;

    printf("Koniec programu \r\n");

    return 0;
}
