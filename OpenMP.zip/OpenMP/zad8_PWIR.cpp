#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <chrono>
#include <cassert>
#include <ctime>
#include <algorithm>
#ifdef _OPENMP
#include <omp.h>
#endif

// Wymiary
constexpr int MATRIX_H = 3000;
constexpr int MATRIX_W = 3000;
constexpr int VECTOR_S = MATRIX_W;
constexpr int RUNS = 10;

uint16_t** matrix;
uint16_t* vector_v;
uint16_t* result;

int main() {
    // Inicjalizacja RNG
    srand(static_cast<unsigned>(time(NULL)));
    assert(MATRIX_W == VECTOR_S);

    // Alokacja macierzy
    matrix = new uint16_t*[MATRIX_H];
    for (int i = 0; i < MATRIX_H; ++i)
        matrix[i] = new uint16_t[MATRIX_W];

    // Alokacja wektorów
    vector_v = new uint16_t[VECTOR_S];
    result   = new uint16_t[MATRIX_H];

    // Wypełnienie danymi losowymi
    for (int i = 0; i < MATRIX_H; ++i)
        for (int k = 0; k < MATRIX_W; ++k)
            matrix[i][k] = rand() % 100;

    for (int i = 0; i < VECTOR_S; ++i)
        vector_v[i] = rand() % 100;

    // 1) Sekwencyjne mnożenie macierzy 10 razy
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int run = 0; run < RUNS; ++run) {
        // zerowanie wyniku
        std::fill_n(result, MATRIX_H, 0);
        for (int i = 0; i < MATRIX_H; ++i) {
            for (int k = 0; k < MATRIX_W; ++k) {
                result[i] += matrix[i][k] * vector_v[k];
            }
        }
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    auto seq_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
    printf("Sekwencyjnie (%d przebiegów) łącznie: %lld ms, średnio: %.2f ms\n",
           RUNS, seq_ms, seq_ms / static_cast<double>(RUNS));

    // 2) Równoległe mnożenie macierzy 10 razy
    auto t2 = std::chrono::high_resolution_clock::now();
    for (int run = 0; run < RUNS; ++run) {
        std::fill_n(result, MATRIX_H, 0);
    #pragma omp parallel for
        for (int i = 0; i < MATRIX_H; ++i) {
            uint32_t sum = 0;
            for (int k = 0; k < MATRIX_W; ++k) {
                sum += matrix[i][k] * vector_v[k];
            }
            result[i] = static_cast<uint16_t>(sum);
        }
    }
    auto t3 = std::chrono::high_resolution_clock::now();
    auto par_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t3 - t2).count();
    printf("Równolegle (%d przebiegów) łącznie: %lld ms, średnio: %.2f ms\n",
           RUNS, par_ms, par_ms / static_cast<double>(RUNS));

    // Zwolnienie pamięci
    delete[] vector_v;
    delete[] result;
    for (int i = 0; i < MATRIX_H; ++i)
        delete[] matrix[i];
    delete[] matrix;

    return 0;
}
