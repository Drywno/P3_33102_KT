#include <omp.h>
#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <algorithm>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Użycie: " << argv[0] << " <N> <BLOCK_SIZE>\n";
        return EXIT_FAILURE;
    }

    int N = std::stoi(argv[1]);
    int BLOCK_SIZE = std::stoi(argv[2]);

    std::vector<std::vector<double>> A(N, std::vector<double>(N));
    std::vector<std::vector<double>> B(N, std::vector<double>(N));
    std::vector<std::vector<double>> C(N, std::vector<double>(N, 0.0));

    std::mt19937_64 rng(
        std::chrono::high_resolution_clock::now().time_since_epoch().count()
    );
    std::uniform_real_distribution<double> dist(0.0, 1.0);

    // wypełniamy macierze A i B
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j) {
            A[i][j] = dist(rng);
            B[i][j] = dist(rng);
        }

    auto t0 = std::chrono::high_resolution_clock::now();

    // pętle bloczkowe z równoległym wnętrzem
    for (int i0 = 0; i0 < N; i0 += BLOCK_SIZE)
      for (int j0 = 0; j0 < N; j0 += BLOCK_SIZE)
        for (int k0 = 0; k0 < N; k0 += BLOCK_SIZE)
          #pragma omp parallel for collapse(2) schedule(static)
          for (int i = i0; i < std::min(i0 + BLOCK_SIZE, N); ++i)
            for (int j = j0; j < std::min(j0 + BLOCK_SIZE, N); ++j) {
                double sum = 0.0;
                for (int k = k0; k < std::min(k0 + BLOCK_SIZE, N); ++k)
                  sum += A[i][k] * B[k][j];
                C[i][j] += sum;
            }

    auto t1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = t1 - t0;

    std::cout << "N = " << N
              << ", BLOCK_SIZE = " << BLOCK_SIZE << "\n"
              << "Czas (OpenMP): " << elapsed.count() << " s\n";

    return EXIT_SUCCESS;
}
