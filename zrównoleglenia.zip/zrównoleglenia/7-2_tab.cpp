#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#define SIZE 10
int data[SIZE];

int main() {
    srand(time(NULL));

  
    printf("Zawartosc tablicy:\n");
    for (int i = 0; i < SIZE; i++) {
        data[i] = rand() % 100;  
        printf("%d ", data[i]);
    }
    printf("\n");

    int max_val = data[0];

#pragma omp parallel
    {
        int local_max = data[0];

#pragma omp for
        for (int i = 0; i < SIZE; i++) {
            if (data[i] > local_max) {
                local_max = data[i];
            }
        }

#pragma omp critical
        {
            if (local_max > max_val) {
                max_val = local_max;
            }
        }
    }

    printf("Najwieksza wartosc w tablicy: %d\n", max_val);

    system("pause");

    return 0;
}
